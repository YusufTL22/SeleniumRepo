package week2.day2;

public class Car {
	public void printCarBrancd () {
		System.out.println("Fortuner");
	}
	public String getCarColour() {
	 	return "Green";
	}
	public long getcarenginenumber () {
		return "2311111111111111l";
	}
	public int subofnumbers 	
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
