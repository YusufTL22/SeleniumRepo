package week2.day2;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=51;i<=77;i=i+2)
	{
		System.out.println(i);
	}
	}

}
