package week2.day2;

public class largestnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] numbers = {22,67,98,1,99};
		Arrays.sort(numbers);
		int length= numbers
		System.out.println(length);
		
		int largestnum = 
	
		

	}

}
