package week3.day2;

import java.util.LinkedHashMap;
import java.util.Map;

public class LearnMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integar, String> map =new LinkedHashMap <Integar, String>();
		map.put(1, "t");
		map.put(1, "e");
		map.put(2, "");
		map.put(1, "t");
		map.put(1, "t");
		map.put(1, "t");
		map.put(1, "t");
		map.put(1, "t");
		
		
		

	}

}
