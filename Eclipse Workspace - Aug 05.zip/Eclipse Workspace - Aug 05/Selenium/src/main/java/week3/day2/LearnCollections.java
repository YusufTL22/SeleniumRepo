package week3.day2;

import java.util.ArrayList;
import java.util.List;

public class LearnCollections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	List <String> list = new ArrayList <String>();
	list.add("Kathik");
	list.add("Arun");
	list.add("Dev");
	list.add("Selva");
	list.add("Anbu");
	list.add("Sekar");
	System.out.println(list);

	
	}

}
