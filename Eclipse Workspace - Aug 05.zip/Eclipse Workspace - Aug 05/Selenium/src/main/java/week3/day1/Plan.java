package week3.day1;

public interface Plan {
public void buildBedRooms (int number);
public void buidBalcony();
public void buildParking();
int totalSqft = 1800;
String name = "Chennai";
String[] flats = {"f1","f2","s1","s2"};

}

