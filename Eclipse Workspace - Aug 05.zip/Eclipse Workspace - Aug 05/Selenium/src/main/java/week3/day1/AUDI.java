package week3.day1;

public class AUDI {
	public void AUDIYear () {
		System.out.println("AUDIYear: 2022");
		
	}

}
