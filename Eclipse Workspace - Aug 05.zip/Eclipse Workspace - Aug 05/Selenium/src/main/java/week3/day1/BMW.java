package week3.day1;

public class BMW {
public void BMWVersion () {
	System.out.println("BMW version: 2.0");	
	
	
}

}
