package week3.day1;

public class Car {
public void carmodel() {
	System.out.println("Car model: Innova");
}

}
