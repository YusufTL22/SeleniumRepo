package week3.day1;

public class Land implements Plan{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
