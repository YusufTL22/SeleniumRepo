package week6.day2;

public class DataProvider {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
