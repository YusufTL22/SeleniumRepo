package week6.day1;

import org.testng.annotations.Test;

public class LearnTestNG {
	@Test
	public void runTestNG () {
		
		// TODO Auto-generated method stub

	}

}
