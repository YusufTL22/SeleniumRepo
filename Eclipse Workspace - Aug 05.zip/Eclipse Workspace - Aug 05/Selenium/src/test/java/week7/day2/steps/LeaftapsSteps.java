package week7.day2.steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LeaftapsSteps {
	ChromeDriver driver;
	@Given("Chrome Browser is opened")
	public void openBrowser (){
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	}
	@And ("Load the applciation URL")
	public void loadURL (){
		driver.get("http://leaftaps.com/opentaps/");
	}
	@And ("Maxmize and set the timeouts")
	public void maxAndTimeout(){
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@And ("Enter username")
	public void enterUsername(){
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
	}
	@And ("Enter password")
	public void enterPassword(){
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}
	@When ("Login button is clicked")
	public void clickLoginButton(){
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	
}
