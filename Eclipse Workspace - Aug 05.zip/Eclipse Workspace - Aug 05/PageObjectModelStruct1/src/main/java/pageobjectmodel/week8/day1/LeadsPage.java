package pageobjectmodel.week8.day1;

import commonclass.ProjectSpecificMethods;

public class LeadsPage extends ProjectSpecificMethods {
	public LeadsPage() {
	}
	public void clickCreateLead () {
	
	}

}
