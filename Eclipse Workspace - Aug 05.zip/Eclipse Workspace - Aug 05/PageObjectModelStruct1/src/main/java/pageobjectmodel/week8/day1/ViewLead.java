package pageobjectmodel.week8.day1;

import commonclass.ProjectSpecificMethods;

public class ViewLead extends ProjectSpecificMethods {
	public ViewLead() {
	}
	public void getLeadID () {
		
	}

}
