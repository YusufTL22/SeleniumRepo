package pageobjectmodel.week8.day1;

import commonclass.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public HomePage() {
	}
	public void clickLeads () {
	
	}

}
