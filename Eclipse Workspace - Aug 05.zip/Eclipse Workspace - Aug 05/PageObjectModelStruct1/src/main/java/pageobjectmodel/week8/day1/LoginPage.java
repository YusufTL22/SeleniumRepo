package pageobjectmodel.week8.day1;

import commonclass.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	public LoginPage() {
	}
	public void enterUserName () {
		
	}
	public void clickLogin () {
	
	}

}
