package pageobjectmodel.week8.day1;

import commonclass.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods {
	public WelcomePage() {
	}
	public void clickCRMSFA () {
		
	}
	public void clickLogout () {
	
	}

}
