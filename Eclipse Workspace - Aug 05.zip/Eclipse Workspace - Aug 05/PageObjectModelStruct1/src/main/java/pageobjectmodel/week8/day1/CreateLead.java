package pageobjectmodel.week8.day1;

import commonclass.ProjectSpecificMethods;

public class CreateLead extends ProjectSpecificMethods {
	public CreateLead() {
	}
	public void enterCompanyName () {
		
	}
	public void enterFirstName () {
		
	}
	public void enterLastName () {
		
	}
	public void clickCreaLead () {
	
	}

}
