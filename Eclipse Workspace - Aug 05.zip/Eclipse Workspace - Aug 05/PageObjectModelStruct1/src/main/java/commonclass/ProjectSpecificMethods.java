package commonclass;

public class ProjectSpecificMethods {

}
